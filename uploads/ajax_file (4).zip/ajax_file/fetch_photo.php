<?php
	include('conn.php');
	if(isset($_POST['fetch'])){
		$inc=4;
		$query=mysqli_query($conn,"select * from photo");
		while($row=mysqli_fetch_array($query)){
		$inc = ($inc == 4) ? 1 : $inc+1; 
		if($inc == 1) echo '<div class="row">';  
 			?>
				<div class="col-lg-3"><img src="<?php echo $row['location']?>" style="height:200px; width:100%;"></div>
 
			<?php
		if($inc == 4) echo '</div>';
		}
		if($inc == 1) echo '<div class="col-lg-3"></div><div class="col-lg-3"></div><div class="col-lg-3"></div></div>'; 
		if($inc == 2) echo '<div class="col-lg-3"></div><div class="col-lg-3"></div></div>'; 
		if($inc == 3) echo '<div class="col-lg-3"></div></div>'; 
	}

?>