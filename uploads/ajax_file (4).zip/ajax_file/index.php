<!DOCTYPE html>
<html>
<head>
    <title>Image Upload using AJAX in PHP/MySQLi</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div style="height:50px;"></div>
  <div class="row">
    <div class="well" style="width:80%; padding:auto; margin:auto">
      <form>
        <h2 align="center" style="color:blue">Image Upload using AJAX in PHP/MySQLi</h2>
        <label>Select Image:</label>
        <input type="file" name="file" id="file"><br>
        <button type="button" id="upload_button" class="btn btn-primary">Upload</button>
      </form>
    </div>
  </div>
  <div style="height:50px;"></div>
  <div style="width:80%; padding:auto; margin:auto;">
      <div id="image_area"></div>
  </div>
</div>
</body>
<script src="custom.js"></script>
</html>
